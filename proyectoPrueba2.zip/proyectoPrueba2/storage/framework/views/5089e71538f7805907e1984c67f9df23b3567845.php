<?php $__env->startSection('content'); ?>

	<div class="col-lg-12 text-center">
                  <h2 class="section-heading">Ingresa al Sistemaaaaaaaaaaaa</h2>
                  <hr class="my-4">
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>