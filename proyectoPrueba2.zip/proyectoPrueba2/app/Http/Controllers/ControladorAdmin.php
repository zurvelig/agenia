<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\LoginRequest;
use App\views\home; //la vista donde esta el registrar
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent;
use App\Http\Models\Usuario;
use Illuminate\Support\Facades\Input;



class ControladorAdmin extends Controller
{
	public function admin()
    {
       return view('administrador');
    }  


}
